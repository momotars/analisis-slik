import os
import re
import pandas as pd
import pdfplumber


def parse_pdf(filepath):
    text_all = ""

    with pdfplumber.open(filepath) as pdf:
        for page in pdf.pages:
            text = page.extract_text() or ""
            text_all += text + "\n"

    return extract_basic_fields(text_all)


def parse_excel(filepath):
    sheets = pd.read_excel(filepath, sheet_name=None, dtype=str)
    combined_text = ""

    for sheet_name, df in sheets.items():
        combined_text += f"\n--- SHEET: {sheet_name} ---\n"
        combined_text += df.fillna("").to_string(index=False)

    return extract_basic_fields(combined_text)


def parse_rupiah(value):
    if not value:
        return 0

    value = str(value).strip()
    value = value.replace("Rp", "").replace(" ", "")

    if "," in value:
        value = value.split(",")[0]

    value = re.sub(r"[^0-9]", "", value)
    return int(value) if value else 0


def find_first(pattern, text, default=""):
    match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
    if match:
        return match.group(1).strip()
    return default


def clean_name(value):
    if not value:
        return ""

    value = value.replace("Tanggal Update", "")
    value = value.replace("Nama Sesuai Identitas", "")
    value = value.replace("Nama", "")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def extract_basic_fields(text):
    # =========================
    # NORMALISASI TEXT
    # =========================
    text = text.replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)

    # =========================
    # DATA DEBITUR
    # =========================
    nama = ""

    nama_match = re.search(
        r"\n([A-Z][A-Z\s]{3,80}?)\s+NIK\s*/",
        text,
        re.IGNORECASE
    )

    if nama_match:
        nama = clean_name(nama_match.group(1))

    if not nama:
        nama_match = re.search(
            r"Nama Sesuai Identitas.*?\n([A-Z][A-Z\s]{3,80})",
            text,
            re.IGNORECASE | re.DOTALL
        )
        if nama_match:
            nama = clean_name(nama_match.group(1))

    # =========================
    # NIK
    # =========================
    nik = find_first(r"NIK\s*/\s*(\d{10,20})", text)

    if not nik:
        nik = find_first(r"Identitas\s+NIK\s*/\s*(\d{10,20})", text)

    # fallback terakhir: ambil angka 16 digit pertama
    if not nik:
        nik_match = re.search(r"\b\d{16}\b", text)
        if nik_match:
            nik = nik_match.group(0)

    # =========================
    # INFO LAPORAN
    # =========================
    nomor_laporan = find_first(
        r"([0-9]+\/IDEB\/[0-9]+\/[0-9]{4})",
        text
    )

    posisi_data = find_first(
        r"Posisi Data Terakhir\s+([A-Za-z]+\s+\d{4})",
        text
    )

    tanggal_permintaan = find_first(
        r"Tanggal Permintaan\s+([0-9]{1,2}\s+[A-Za-z]+\s+\d{4}\s+[0-9:]+)",
        text
    )

    # =========================
    # RINGKASAN FASILITAS
    # =========================
    ringkasan = ""

    ringkasan_match = re.search(
        r"Ringkasan Fasilitas(.*?)(?:Nomor Laporan|Posisi Data Terakhir|Tanggal Permintaan|$)",
        text,
        re.IGNORECASE | re.DOTALL
    )

    if ringkasan_match:
        ringkasan = ringkasan_match.group(1)

    source = ringkasan if ringkasan else text

    # =========================
    # KOLEKTIBILITAS TERBURUK
    # =========================
    kolek = 0
    bulan_kolek = ""

    kolek_match = re.search(
        r"Kualitas Terburuk.*?(\d)\s*/\s*([A-Za-z]+\s+\d{4})",
        source,
        re.IGNORECASE | re.DOTALL
    )

    if not kolek_match:
        kolek_match = re.search(
            r"(\d)\s*/\s*([A-Za-z]+\s+\d{4})",
            source,
            re.IGNORECASE
        )

    if kolek_match:
        kolek = int(kolek_match.group(1))
        bulan_kolek = kolek_match.group(2).strip()

    # =========================
    # PLAFON & BAKI DEBET
    # =========================
    total_plafon = 0
    total_baki_debet = 0

    plafon_match = re.search(
        r"Plafon Efektif\s+([\d\.,]+)",
        source,
        re.IGNORECASE
    )

    baki_match = re.search(
        r"Baki Debet\s+([\d\.,]+)",
        source,
        re.IGNORECASE
    )

    if plafon_match:
        total_plafon = parse_rupiah(plafon_match.group(1))

    if baki_match:
        total_baki_debet = parse_rupiah(baki_match.group(1))

    # =========================
    # JUMLAH KREDITUR
    # =========================
    bank_umum = 0
    bpr_bprs = 0
    lembaga_pembiayaan = 0
    lainnya = 0

    kreditur_match = re.search(
        r"Jumlah Kreditur\s+Bank Umum\s+(\d+)\s+BPR\s*/\s*BPRS\s+(\d+)\s+Lembaga Pembiayaan\s+(\d+)\s+Lainnya\s+(\d+)",
        source,
        re.IGNORECASE | re.DOTALL
    )

    if kreditur_match:
        bank_umum = int(kreditur_match.group(1))
        bpr_bprs = int(kreditur_match.group(2))
        lembaga_pembiayaan = int(kreditur_match.group(3))
        lainnya = int(kreditur_match.group(4))

    jumlah_kreditur = bank_umum + bpr_bprs + lembaga_pembiayaan + lainnya

    # =========================
    # TUNGGAKAN
    # =========================
    tunggakan_pokok_values = re.findall(
        r"Tunggakan Pokok\s+Rp\s*([\d\.,]+)",
        text,
        re.IGNORECASE
    )

    tunggakan_bunga_values = re.findall(
        r"Tunggakan Bunga\s+Rp\s*([\d\.,]+)",
        text,
        re.IGNORECASE
    )

    total_tunggakan = sum(parse_rupiah(x) for x in tunggakan_pokok_values)
    total_tunggakan += sum(parse_rupiah(x) for x in tunggakan_bunga_values)

    # =========================
    # FASILITAS
    # =========================
    jumlah_aktif = len(re.findall(r"Kondisi\s+Fasilitas Aktif", text, re.IGNORECASE))
    jumlah_lunas = len(re.findall(r"Kondisi\s+Lunas", text, re.IGNORECASE))
    jumlah_fasilitas = jumlah_aktif + jumlah_lunas

    return {
        "nama": nama,
        "nik": nik,
        "nomor_laporan": nomor_laporan,
        "posisi_data": posisi_data,
        "tanggal_permintaan": tanggal_permintaan,

        "kolektibilitas_list": [kolek] if kolek else [],
        "kolektibilitas_terburuk": kolek,
        "bulan_kolektibilitas_terburuk": bulan_kolek,

        "jumlah_indikasi_fasilitas": jumlah_fasilitas,
        "jumlah_kreditur": jumlah_kreditur,
        "bank_umum": bank_umum,
        "bpr_bprs": bpr_bprs,
        "lembaga_pembiayaan": lembaga_pembiayaan,
        "lainnya": lainnya,

        "jumlah_lunas": jumlah_lunas,
        "jumlah_aktif": jumlah_aktif,

        "total_tunggakan": total_tunggakan,
        "total_plafon": total_plafon,
        "total_baki_debet": total_baki_debet,

        "raw_text_preview": text[:5000]
    }


def parse_slik_file(filepath):
    ext = os.path.splitext(filepath)[1].lower()

    if ext == ".pdf":
        return parse_pdf(filepath)

    if ext in [".xlsx", ".xls"]:
        return parse_excel(filepath)

    raise ValueError("Format file tidak didukung") 