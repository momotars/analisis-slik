from flask import Flask, render_template, request, redirect, flash, session, send_file, abort
import os
import tempfile
from functools import wraps
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

from parser_slik import parse_slik_file
from analyzer import analyze_slik
from ai_helper import generate_ai_analysis
from database import init_db, save_history, get_history

from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet


# =========================
# LOAD ENV
# =========================
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "fallback-secret")

UPLOAD_FOLDER = "uploads"
ALLOWED_EXTENSIONS = {"pdf", "xlsx", "xls"}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

init_db()


# =========================
# USER MANAGEMENT
# Format .env:
# APP_USERS=admin:admin123:admin,staff:staff123:user
# =========================
def load_users():
    users_raw = os.getenv("APP_USERS", "")
    users = {}

    for item in users_raw.split(","):
        item = item.strip()
        if not item:
            continue

        parts = item.split(":")
        if len(parts) != 3:
            continue

        username, password, role = parts
        users[username] = {
            "password": password,
            "role": role
        }

    return users


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect("/login")
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect("/login")

        if session.get("role") != "admin":
            abort(403)

        return f(*args, **kwargs)
    return wrapper


# =========================
# AUTH
# =========================
@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("logged_in"):
        return redirect("/")

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        users = load_users()
        user = users.get(username)

        if user and password == user["password"]:
            session["logged_in"] = True
            session["username"] = username
            session["role"] = user["role"]
            return redirect("/")

        flash("Username atau password salah.")
        return redirect("/login")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")


# =========================
# MAIN PAGE
# =========================
@app.route("/", methods=["GET", "POST"])
@login_required
def index():
    if request.method == "POST":

        if "file" not in request.files:
            flash("File belum dipilih.")
            return redirect(request.url)

        file = request.files["file"]

        if file.filename == "":
            flash("File belum dipilih.")
            return redirect(request.url)

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(filepath)

            extracted = parse_slik_file(filepath)
            result = analyze_slik(extracted)
            ai_text = generate_ai_analysis(extracted)

            save_history(
                username=session.get("username", "unknown"),
                filename=filename,
                extracted=extracted,
                result=result,
                ai_text=ai_text
            )

            session["last_result"] = {
                "extracted": extracted,
                "result": result,
                "ai_text": ai_text,
                "filename": filename
            }

            return render_template(
                "result.html",
                extracted=extracted,
                result=result,
                ai_text=ai_text,
                filename=filename,
                role=session.get("role")
            )

        flash("Format file tidak didukung.")
        return redirect(request.url)

    return render_template(
        "index.html",
        role=session.get("role")
    )


# =========================
# EXPORT PDF
# =========================
@app.route("/export-pdf")
@login_required
def export_pdf():
    data = session.get("last_result")

    if not data:
        flash("Belum ada data.")
        return redirect("/")

    styles = getSampleStyleSheet()
    pdf_file = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")

    doc = SimpleDocTemplate(pdf_file.name, pagesize=A4)
    elements = []

    elements.append(Paragraph("Laporan Analisis SLIK", styles["Title"]))
    elements.append(Spacer(1, 12))

    elements.append(Paragraph(f"Nama: {data['extracted'].get('nama', '-')}", styles["Normal"]))
    elements.append(Paragraph(f"NIK: {data['extracted'].get('nik', '-')}", styles["Normal"]))
    elements.append(Paragraph(f"Nomor Laporan: {data['extracted'].get('nomor_laporan', '-')}", styles["Normal"]))
    elements.append(Spacer(1, 12))

    elements.append(Paragraph(data["ai_text"] or "AI tidak tersedia.", styles["Normal"]))

    doc.build(elements)

    return send_file(
        pdf_file.name,
        as_attachment=True,
        download_name="laporan_analisis_slik.pdf"
    )


# =========================
# HISTORY - ADMIN ONLY
# =========================
@app.route("/history")
@admin_required
def history():
    data = get_history()
    return render_template("history.html", data=data)


# =========================
# ERROR PAGE
# =========================
@app.errorhandler(403)
def forbidden(e):
    return """
    <h3>Akses ditolak</h3>
    <p>Halaman ini hanya bisa diakses oleh admin.</p>
    <a href="/">Kembali</a>
    """, 403


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80, debug=True)