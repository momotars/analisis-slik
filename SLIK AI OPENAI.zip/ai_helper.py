import os
import requests
from openai import OpenAI
from dotenv import load_dotenv

# Load .env
load_dotenv()

# Ambil API key dari .env
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Model Ollama
OLLAMA_MODEL = "qwen2.5:3b"

# Init OpenAI client kalau ada key
client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None


def format_rupiah(value):
    try:
        return "Rp {:,}".format(int(value)).replace(",", ".")
    except Exception:
        return "Rp 0"


def build_prompt(data):
    return f"""
Kamu adalah analis kredit bank di Indonesia.

WAJIB menggunakan Bahasa Indonesia formal dan profesional.
JANGAN menggunakan Bahasa Inggris.

Tugas kamu adalah membuat laporan analisis SLIK seperti analis kredit bank.

FORMAT WAJIB:

=== ANALISIS SLIK DEBITUR ===

1. Ringkasan Profil
- Nama:
- Kolektibilitas:
- Jumlah Kreditur:
- Total Plafon:
- Baki Debet:
- Total Tunggakan:

2. Analisis Risiko
Jelaskan kondisi kredit secara ringkas dan jelas. Apakah sehat atau berpotensi risiko.

3. Catatan Penting
Soroti hal yang perlu diperhatikan analis (jumlah kreditur, potensi overleverage, dll).

4. Rekomendasi
Berikan saran untuk analis. JANGAN ambil keputusan final.

Data SLIK:

Nama: {data.get('nama', '-')}
Kolektibilitas: {data.get('kolektibilitas_terburuk', '-')} / {data.get('bulan_kolektibilitas_terburuk', '-')}
Jumlah kreditur: {data.get('jumlah_kreditur', 0)}
Bank umum: {data.get('bank_umum', 0)}
BPR/BPRS: {data.get('bpr_bprs', 0)}
Lembaga pembiayaan: {data.get('lembaga_pembiayaan', 0)}
Total plafon: {format_rupiah(data.get('total_plafon', 0))}
Baki debet: {format_rupiah(data.get('total_baki_debet', 0))}
Total tunggakan: {format_rupiah(data.get('total_tunggakan', 0))}
Fasilitas aktif: {data.get('jumlah_aktif', 0)}
Fasilitas lunas: {data.get('jumlah_lunas', 0)}
"""


def generate_with_openai(prompt):
    if not client:
        raise Exception("OpenAI API key tidak tersedia")

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": "Kamu adalah analis kredit bank Indonesia. Gunakan Bahasa Indonesia formal."
            },
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response.choices[0].message.content


def generate_with_ollama(prompt):
    response = requests.post(
        "http://localhost:11434/api/generate",
        json={
            "model": OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False
        },
        timeout=120
    )

    response.raise_for_status()
    return response.json().get("response")


def generate_ai_analysis(data):
    prompt = build_prompt(data)

    # 1. Coba OpenAI
    try:
        return generate_with_openai(prompt)
    except Exception as e:
        print("OpenAI gagal → pakai Ollama:", e)

    # 2. Fallback ke Ollama
    try:
        return generate_with_ollama(prompt)
    except Exception as e:
        print("Ollama gagal:", e)

    # 3. Semua gagal
    return None