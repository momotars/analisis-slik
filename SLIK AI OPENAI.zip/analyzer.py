def format_rupiah(value):
    try:
        return "Rp {:,}".format(int(value)).replace(",", ".")
    except Exception:
        return "Rp 0"


def analyze_slik(data):
    score = 0
    findings = []

    kolek = data.get("kolektibilitas_terburuk", 0)
    tunggakan = data.get("total_tunggakan", 0)
    jumlah_fasilitas = data.get("jumlah_indikasi_fasilitas", 0)
    baki_debet = data.get("total_baki_debet", 0)

    if kolek >= 5:
        score += 50
        findings.append("Terdapat riwayat kolektibilitas 5 atau macet.")
    elif kolek == 4:
        score += 40
        findings.append("Terdapat riwayat kolektibilitas 4 atau diragukan.")
    elif kolek == 3:
        score += 30
        findings.append("Terdapat riwayat kolektibilitas 3 atau kurang lancar.")
    elif kolek == 2:
        score += 15
        findings.append("Terdapat riwayat kolektibilitas 2 atau dalam perhatian khusus.")
    elif kolek == 1:
        findings.append("Kolektibilitas terburuk terdeteksi lancar.")
    else:
        findings.append("Data kolektibilitas belum terdeteksi oleh parser awal.")

    if tunggakan > 0:
        score += 25
        findings.append(f"Terdapat indikasi tunggakan sebesar {format_rupiah(tunggakan)}.")

    if jumlah_fasilitas >= 5:
        score += 15
        findings.append("Jumlah indikasi fasilitas kredit cukup banyak.")
    elif jumlah_fasilitas > 0:
        findings.append(f"Terdapat indikasi {jumlah_fasilitas} fasilitas/kata kunci kredit.")

    if baki_debet >= 100_000_000:
        score += 10
        findings.append(f"Total indikasi baki debet cukup besar yaitu {format_rupiah(baki_debet)}.")

    if score >= 60:
        risk = "TINGGI"
        recommendation = "Perlu analisis mendalam, klarifikasi riwayat tunggakan/kolektibilitas, dan pertimbangan mitigasi risiko tambahan."
    elif score >= 30:
        risk = "SEDANG"
        recommendation = "Perlu verifikasi tambahan oleh analis, terutama pada riwayat kolektibilitas, tunggakan, dan kemampuan bayar."
    else:
        risk = "RENDAH"
        recommendation = "Secara awal risiko terlihat rendah, namun tetap wajib diverifikasi dengan data penghasilan, agunan, dan analisis kredit internal."

    return {
        "score": score,
        "risk": risk,
        "findings": findings,
        "recommendation": recommendation
    }
